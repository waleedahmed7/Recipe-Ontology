
 <?php
    $connection=mysqli_connect("localhost","root","","populate");
    if(mysqli_connect_errno()){
        echo"error";}
        else{
            echo"ok";}
   ?> 
<!doctype html>
<html lang="en">
  <head>
    <title>form</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
  <body>
    <form method="post">
    <label><b>Name</b></label>
        <label style="margin-left:44%" ><b> Father Name</b></label>
        <br>
        <br>
        <input type="text" name="name" placeholder="&nbsp;&nbsp;Enter your email" size="25" class="email" style="border-radius:5px;height:20px; border:none; " required>
        <input type="text" name="fname" placeholder="&nbsp;&nbsp;Enter your NAME" size="25" style="border-radius:5px;height:20px; border:none; margin-left:20%" required>
        <br>
        <br><label><b>roll no</b></label>
        <label style="margin-left:44%" ><b> cnic</b></label>
        <br>
        <br>
        <input type="text" name="rollno" placeholder="&nbsp;&nbsp;Enter your email" size="25" class="email" style="border-radius:5px;height:20px; border:none; " required>
        <input type="text" name="cnic" placeholder="&nbsp;&nbsp;Enter your NAME" size="25" style="border-radius:5px;height:20px; border:none; margin-left:20%" required>
        <br>
        <br><label><b>school</b></label>
        <label style="margin-left:44%" ><b>KG standard</b></label>
        <br>
        <br>
        <input type="text" name="school" placeholder="&nbsp;&nbsp;Enter your email" size="25" class="email" style="border-radius:5px;height:20px; border:none; " required>
        <input type="text" name="kgstandard" placeholder="&nbsp;&nbsp;Enter your NAME" size="25" style="border-radius:5px;height:20px; border:none; margin-left:20%" >
        <br>
        <br>

        <br><label><b>Low standard</b></label>
        <label style="margin-left:44%" ><b>High standard</b></label>
        <br>
        <br>
        <input type="text" name="lstandard" placeholder="&nbsp;&nbsp;Enter your email" size="25" class="email" style="border-radius:5px;height:20px; border:none; ">
        <input type="text" name="hstandard" placeholder="&nbsp;&nbsp;Enter your NAME" size="25" style="border-radius:5px;height:20px; border:none; margin-left:20%" >
        <br>
        <br>
        <button type="submit" style=" margin-left:40%; height:30px; width:14%; background-color:#06C; border:none; border-radius:5px" name="insert" data-toggle="modal" >Insert</button>
      
    </form>
    <?php
if(isset($_POST['insert']))
{
		//donar data start
	$name=$_POST['name'];
	$fname=$_POST['fname'];
	$rollno=$_POST['rollno'];
	$cnic=$_POST['cnic'];
	$school=$_POST['school'];
	$kgstandard=$_POST['kgstandard'];
	$lstandard=$_POST['lstandard'];
    $hstandard=$_POST['hstandard'];
    $queryd="INSERT INTO student values (NULL,'$name' ,'$fname','$rollno','$cnic','$school','$kgstandard','$lstandard','$hstandard')";
	
    If(mysqli_query($connection, $queryd))
    {
        echo"<script>alert('Congratulation! Data Inserted in Table')</script><br>";
    }
}?> 
      <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>