<?php
    $connection=mysqli_connect("localhost","root","","group1");
    if(mysqli_connect_errno()){
        echo"error";}
        else{
            echo"";}
   ?> 

<!doctype html>
<html lang="en">
  <head>
    <title>Ontology Populate</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
  <body>
  <?php   
   
   $query="select * from recipes LIMIT 0,2";
   $run=mysqli_query($connection, $query);
   while($row=mysqli_fetch_array($run)){  
      
        $recipeid=$row[0];
       $name=$row[1];
       $auther=$row[2];
       $image=$row[3];
       $url=$row[4];
       $prepTime=$row[5];
       $cookTime=$row[6];
       $totalTime=$row[7];
       $yield=$row[8];
       $recipeyield=$row[9];
       $commentCount=$row[10];
       $aggregateCount=$row[11];
       $aggregateRating=$row[12];
       $recipeCategory=$row[13];
       $recipeCuisine=$row[14];
       $suitableforDiet=$row[15];
       $performTime=$row[16];
       $dateCreated=$row[17];
       $datePublished=$row[18];
       $contentRating=$row[19];
       $dateModified=$row[20];
       $keywords=$row[21];
       $cookingMethods=$row[22];
       $estimatedCost=$row[23];
       $tools=$row[24];
       $recipecourse=$row[25];
       $chillTime=$row[26];
       $marinateTime=$row[27];
       $recipeComplexity=$row[28];
       $CustomTime=$row[29];



            $nutritionquery="select * from nutrition where id='$recipeid'";
            $nutritionrun=mysqli_query($connection, $nutritionquery);
              while($row=mysqli_fetch_array($nutritionrun)){  
            
            
            $calories =$row[1];
            $fatContent =$row[2];
            $sodiumContent =$row[3];
            $carbohyderateContent =$row[4];
            $cholesterolContent =$row[5];
            $fiberContent =$row[6];
            $proteinContent=$row[7];
            $saturatedFatContent =$row[8];
            $servingSize=$row[9];
            $sugarContent =$row[10];
            $transFatContent =$row[11];
            $unsaturatedFatContent =$row[12];
            $fatCaloriesContent=$row[13];
            $calciumContent =$row[14];
            $vitaminAContent =$row[15];
            $vitaminCContent =$row[16];
            $vitaminB1Content=$row[17];
            $vitaminB2Content=$row[18];
            $vitaminB3Content=$row[19];
            $vitaminB6Content=$row[20];
            $vitaminB9Content=$row[21];
            $vitaminB12Content=$row[22];
            $vitaminEContent=$row[23];
            $vitaminKContent =$row[24];
            $magnessiumContent =$row[25];
            $phosphorusContent=$row[26];
            $zincContent =$row[27];
            $monounsaturatedFatContent =$row[28];
            $polyunsaturatedFatContent =$row[29];
            $potassiumContent =$row[30];
            $carbsContent  =$row[31];
            $sugarCarbsContent =$row[32];
            $fiberCarbsContent =$row[33];
            $totalCarbsContent =$row[34];
            $totalFatContent  =$row[35];
            $dietaryFiberContent =$row[36];
            $ironContent =$row[37];
            $caloriesFromFat =$row[38];
            
    
   
   
       
       
        
?>

       <p>< !-- https://hajirajabeen.github.io/EvoRecipesOntology#<?php echo $name?>--></p>
       <p>< owl:NamedIndividual rdf:about="https://hajirajabeen.github.io/EvoRecipesOntology#<?php echo $name?>"></p>
       <p>< rdf:type rdf:resource="http://schema.org/Recipe"/></p>
      <p>< hasAggregateRating rdf:resource="https://hajirajabeen.github.io/EvoRecipesOntology#<?php echo $aggregateRating?>"/></p>
      <p>< hasNutrientType rdf:resource="https://hajirajabeen.github.io/EvoRecipesOntology#<?php echo $recipeid."-"?>calories"/></p>
      <p>< hasNutrientType rdf:resource="https://hajirajabeen.github.io/EvoRecipesOntology#<?php echo $recipeid."-"?>fatContent"/></p>
      <p>< /owl:NamedIndividual></p>
       <br><br>


       <p>< !-- https://hajirajabeen.github.io/EvoRecipesOntology#<?php echo $recipeid."-"?>fatContent  --></p>
       <p>< owl:NamedIndividual rdf:about="https://hajirajabeen.github.io/EvoRecipesOntology#<?php echo $recipeid."-"?>fatContent"></p>
       <p>< rdf:type rdf:resource="https://hajirajabeen.github.io/EvoRecipesOntology#Nutrient"/></p>
      <p>< hasNutrientQuantity rdf:resource="https://hajirajabeen.github.io/EvoRecipesOntology#<?php echo $fatContent?>"/></p>
      <p>< qudt:hasUnit rdf:resource="https://hajirajabeen.github.io/EvoRecipesOntology#gram"/></p>
      <p>< /owl:NamedIndividual></p>
       <br><br>



       <p>< !-- https://hajirajabeen.github.io/EvoRecipesOntology#<?php echo $recipeid."-"?>calories --></p>
       <p>< owl:NamedIndividual rdf:about="https://hajirajabeen.github.io/EvoRecipesOntology#<?php echo $recipeid."-"?>calories"></p>
       <p>< rdf:type rdf:resource="https://hajirajabeen.github.io/EvoRecipesOntology#Nutrient"/></p>
      <p>< hasNutrientQuantity rdf:resource="https://hajirajabeen.github.io/EvoRecipesOntology#<?php echo $calories?>"/></p>
      <p>< qudt:hasUnit rdf:resource="https://hajirajabeen.github.io/EvoRecipesOntology#Kcl"/></p>
      <p>< /owl:NamedIndividual></p>
       <br><br>


       <p>< !-- https://hajirajabeen.github.io/EvoRecipesOntology#Kcl --></p>
       <p>< owl:NamedIndividual rdf:about="https://hajirajabeen.github.io/EvoRecipesOntology#Kcl"></p>
       <p>< rdf:type rdf:resource="http://qudt.org/2.1/schema/qudt#Unit"/></p>
      <p>< /owl:NamedIndividual></p>
       <br><br>

       <p>< !-- https://hajirajabeen.github.io/EvoRecipesOntology#gram --></p>
       <p>< owl:NamedIndividual rdf:about="https://hajirajabeen.github.io/EvoRecipesOntology#gram"></p>
       <p>< rdf:type rdf:resource="http://qudt.org/2.1/schema/qudt#Unit"/></p>
      <p>< /owl:NamedIndividual></p>
       <br><br>


       <p>< !-- https://hajirajabeen.github.io/EvoRecipesOntology#<?php echo $calories?>--></p>
       <p>< owl:NamedIndividual rdf:about="https://hajirajabeen.github.io/EvoRecipesOntology#<?php echo $calories?>"></p>
       <p>< rdf:type rdf:resource="http://qudt.org/2.1/schema/qudt#Quantity"/></p>
      <p>< /owl:NamedIndividual></p>
       <br><br>
        

       <p>< !-- https://hajirajabeen.github.io/EvoRecipesOntology#<?php echo $fatContent?>--></p>
       <p>< owl:NamedIndividual rdf:about="https://hajirajabeen.github.io/EvoRecipesOntology#<?php echo $fatContent?>"></p>
       <p>< rdf:type rdf:resource="http://qudt.org/2.1/schema/qudt#Quantity"/></p>
      <p>< /owl:NamedIndividual></p>
       <br><br>


       <p>< !-- https://hajirajabeen.github.io/EvoRecipesOntology#<?php echo $aggregateRating?>--></p>
       <p>< owl:NamedIndividual rdf:about="https://hajirajabeen.github.io/EvoRecipesOntology#<?php echo $aggregateRating?>"></p>
       <p>< rdf:type rdf:resource="http://schema.org/AggregateRating"/></p>
        <p>< /owl:NamedIndividual></p>
       <br><br>


      

<?php

        }
          }
          $ingrediantquery="select * from nutrition where id='$recipeid'";
          $ingrediantrun=mysqli_query($connection, $ingrediantquery);
            while($row=mysqli_fetch_array($ingrediantrun)){
         ?>
      <?php }?>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>