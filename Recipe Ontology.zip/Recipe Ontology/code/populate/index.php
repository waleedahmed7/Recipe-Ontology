<?php
    $connection=mysqli_connect("localhost","root","","populate");
    if(mysqli_connect_errno()){
        echo"error";}
        else{
            echo"";}
   ?> 

<!doctype html>
<html lang="en">
  <head>
    <title>Title</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
  <body>
  <?php   
   
    $query="select * from student ";
    $run=mysqli_query($connection, $query);
    while($row=mysqli_fetch_array($run)){  
       
         $id=$row[0];
        $name=$row[1];
        $fname=$row[2];
        $rollno=$row[3];
        $cnic=$row[4];
        $school=$row[5];
        $kgstandard=$row[6];
        $lstandard=$row[7];
        $hstandard=$row[8];
    
    
        
        
         
?>

         <p>< !-- http://www.semanticweb.org/alizeeshan/ontologies/2021/11/untitled-ontology-45#<?php echo $name?>--></p>
         <p>< owl:NamedIndividual rdf:about="http://www.semanticweb.org/alizeeshan/ontologies/2021/11/untitled-ontology-45#<?php echo $name?>"></p>
         <p>< rdf:type rdf:resource="http://www.semanticweb.org/alizeeshan/ontologies/2021/11/untitled-ontology-45#name"/></p>
         <p>< untitled-ontology-45:haveFatherName rdf:resource="http://www.semanticweb.org/alizeeshan/ontologies/2021/11/untitled-ontology-45#<?php echo $fname?>"/></p>
         <p>< untitled-ontology-45:haveRollno rdf:resource="http://www.semanticweb.org/alizeeshan/ontologies/2021/11/untitled-ontology-45#<?php echo $rollno ?>"/></p>
         <p>< untitled-ontology-45:haveCNIC rdf:resource="http://www.semanticweb.org/alizeeshan/ontologies/2021/11/untitled-ontology-45#<?php echo $cnic ?>"/></p>
         <p>< untitled-ontology-45:readIn rdf:resource="http://www.semanticweb.org/alizeeshan/ontologies/2021/11/untitled-ontology-45#<?php echo $school ?>"/></p>
         <p>< untitled-ontology-45:havehigherStandard rdf:resource="http://www.semanticweb.org/alizeeshan/ontologies/2021/11/untitled-ontology-45#<?php echo $hstandard ?>"/></p>
         <p>< untitled-ontology-45:havekgStandard rdf:resource="http://www.semanticweb.org/alizeeshan/ontologies/2021/11/untitled-ontology-45#<?php echo $kgstandard ?>"/></p>
         <p>< untitled-ontology-45:havemiddleStandard rdf:resource="http://www.semanticweb.org/alizeeshan/ontologies/2021/11/untitled-ontology-45#<?php echo $lstandard ?>"/></p>
         
         <p>< /owl:NamedIndividual> </p><br><br>

         <p>< !-- http://www.semanticweb.org/alizeeshan/ontologies/2021/11/untitled-ontology-45#<?php echo $fname?>--></p>
         <p>< owl:NamedIndividual rdf:about="http://www.semanticweb.org/alizeeshan/ontologies/2021/11/untitled-ontology-45#<?php echo $fname?>"></p>
         <p> < rdf:type rdf:resource="http://www.semanticweb.org/alizeeshan/ontologies/2021/11/untitled-ontology-45#father_name"/></p>
         <p>< /owl:NamedIndividual> </p><br><br>

         <p>< !-- http://www.semanticweb.org/alizeeshan/ontologies/2021/11/untitled-ontology-45#<?php echo $rollno?>--></p>
         <p>< owl:NamedIndividual rdf:about="http://www.semanticweb.org/alizeeshan/ontologies/2021/11/untitled-ontology-45#<?php echo $rollno?>"></p>
         <p> < rdf:type rdf:resource="http://www.semanticweb.org/alizeeshan/ontologies/2021/11/untitled-ontology-45#roll_no"/></p>
         <p>< /owl:NamedIndividual> </p><br><br>

         <p>< !-- http://www.semanticweb.org/alizeeshan/ontologies/2021/11/untitled-ontology-45#<?php echo $cnic?>--></p>
         <p>< owl:NamedIndividual rdf:about="http://www.semanticweb.org/alizeeshan/ontologies/2021/11/untitled-ontology-45#<?php echo $cnic?>"></p>
         <p> < rdf:type rdf:resource="http://www.semanticweb.org/alizeeshan/ontologies/2021/11/untitled-ontology-45#cnic"/></p>
         <p>< /owl:NamedIndividual> </p><br><br>

         <p>< !-- http://www.semanticweb.org/alizeeshan/ontologies/2021/11/untitled-ontology-45#<?php echo $school?>--></p>
         <p>< owl:NamedIndividual rdf:about="http://www.semanticweb.org/alizeeshan/ontologies/2021/11/untitled-ontology-45#<?php echo $school?>"></p>
         <p> < rdf:type rdf:resource="http://www.semanticweb.org/alizeeshan/ontologies/2021/11/untitled-ontology-45#school"/></p>
         <p>< /owl:NamedIndividual> </p><br><br>

         <p>< !-- http://www.semanticweb.org/alizeeshan/ontologies/2021/11/untitled-ontology-45#<?php echo $school?>--></p>
         <p>< owl:NamedIndividual rdf:about="http://www.semanticweb.org/alizeeshan/ontologies/2021/11/untitled-ontology-45#<?php echo $school?>"></p>
         <p> < rdf:type rdf:resource="http://www.semanticweb.org/alizeeshan/ontologies/2021/11/untitled-ontology-45#school"/></p>
         <p>< /owl:NamedIndividual> </p><br><br>

         <p>< !-- http://www.semanticweb.org/alizeeshan/ontologies/2021/11/untitled-ontology-45#<?php echo $kgstandard?>--></p>
         <p>< owl:NamedIndividual rdf:about="http://www.semanticweb.org/alizeeshan/ontologies/2021/11/untitled-ontology-45#<?php echo $kgstandard?>"></p>
         <p> < rdf:type rdf:resource="http://www.semanticweb.org/alizeeshan/ontologies/2021/11/untitled-ontology-45#kg_standard"/></p>
         <p>< /owl:NamedIndividual> </p><br><br>

         <p>< !-- http://www.semanticweb.org/alizeeshan/ontologies/2021/11/untitled-ontology-45#<?php echo $lstandard?>--></p>
         <p>< owl:NamedIndividual rdf:about="http://www.semanticweb.org/alizeeshan/ontologies/2021/11/untitled-ontology-45#<?php echo $lstandard?>"></p>
         <p> < rdf:type rdf:resource="http://www.semanticweb.org/alizeeshan/ontologies/2021/11/untitled-ontology-45#middle_standard"/></p>
         <p>< /owl:NamedIndividual> </p><br><br>

         <p>< !-- http://www.semanticweb.org/alizeeshan/ontologies/2021/11/untitled-ontology-45#<?php echo $hstandard?>--></p>
         <p>< owl:NamedIndividual rdf:about="http://www.semanticweb.org/alizeeshan/ontologies/2021/11/untitled-ontology-45#<?php echo $hstandard?>"></p>
         <p> < rdf:type rdf:resource="http://www.semanticweb.org/alizeeshan/ontologies/2021/11/untitled-ontology-45#Higher_standard"/></p>
         <p>< /owl:NamedIndividual> </p><br><br>

         <?php
          }
         ?>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>